#β0=0.597
#install.packages("doParallel")
#install.packages("ResourceSelection")
#install.packages("devtools")
library(devtools)
install_github("gnattino/largesamplehl")


rm(list = ls(all = TRUE))
library(doParallel)
library(ResourceSelection)
library(largesamplehl)
#Sample Size and Parameter Settings
col <- 2
cols <- col + 1
rows <- 500
n_sim <- 1000
sig <- 1

n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
}
n1 <- function(x, theta, sig) {
  f = sig * exp(x[,2] * x[,3])
  pro = 1 / (1 + exp(-((x) %*% theta + f)))
  return(pro)
}

theta <- matrix(c(0.597,0.483,1.664))
num_cores <- detectCores()
cl <- makeCluster(max(1, num_cores - 3))
registerDoParallel(cl)

results <- foreach(i = 1:n_sim, .combine = 'rbind', .packages = c("ResourceSelection", "largesamplehl")) %dopar% {
  set.seed(1433+i)
  ma92 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
  ma92[,1] <- 1
  Z=n(ma92,theta)
  label <- as.integer(runif(rows) < Z)
  ma921 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
  ma921[,1] <- 1
  Z1=n1(ma921,theta,sig)
  label1 <- as.integer(runif(rows) < Z1)
  model <- glm(label ~., 
               data = data.frame(ma92[,-1]), 
               family = binomial(link = "logit"))
  Mprob <- predict(model, data.frame(ma921[,-1]), type = "response")
  n_obs <- length(label1)
  
  
  greenwood <- ifelse(label1 == 1, runif(n_obs, 0, Mprob), runif(n_obs, Mprob, 1))
  ui <- c(0, sort(greenwood), 1)
  D <- diff(ui)
  D_sorted <- sort(D)
  n_D <- length(D_sorted)
  indices <- 0:(n_D - 1)
  
  
  term1 <- sum(D_sorted * indices)
  prefix_sum <- cumsum(c(0, D_sorted[-n_D]))  
  term2 <- sum(prefix_sum)
  Gn <- 2 * (term1 - term2)
  greenwood_stat <- (Gn - n_obs) / sqrt(n_obs / 3)
  greenwood_pval <- greenwood_stat^2
  
  
  hl_result <- tryCatch({
    hoslem.test(label1, Mprob, g = 10)
  }, error = function(e) NULL)
  
  
  nattino_result <- tryCatch({
    hltest(label1, Mprob, G = 10, outsample = TRUE)
  }, error = function(e) NULL)
  
  c(greenwood_pval = greenwood_pval,
    hl_pval = if(!is.null(hl_result)) hl_result$statistic else NA,
    nattino_pval = if(!is.null(nattino_result)) nattino_result$p.value else NA)
}


stopCluster(cl)

# alpha level
greenwood_pvals <- results[, 1]
hl_pvals <- results[, 2]
nattino_pvals <- results[, 3]



p1.05 <- mean(greenwood_pvals > qchisq(0.95, df = 1))
p2.05 <- mean(hl_pvals > qchisq(0.95, df = 10))
p3.05 <- mean(nattino_pvals < 0.05)


#  result
list(
  greenwood = c(p1.05 = p1.05),
  hl = c(p2.05 = p2.05),
  nattino = c(p3.05 = p3.05)
)


#β0=-1
rm(list = ls(all = TRUE))
library(doParallel)
library(ResourceSelection)
library(largesamplehl)
#Sample Size and Parameter Settings
col <- 2
cols <- col + 1
rows <- 500
n_sim <- 1000
sig <- 1

n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
}
n1 <- function(x, theta, sig) {
  f = sig * exp(x[,2] * x[,3])
  pro = 1 / (1 + exp(-((x) %*% theta + f)))
  return(pro)
}

theta <- matrix(c(-1,0.483,1.664))
num_cores <- detectCores()
cl <- makeCluster(max(1, num_cores - 3))
registerDoParallel(cl)

results <- foreach(i = 1:n_sim, .combine = 'rbind', .packages = c("ResourceSelection", "largesamplehl")) %dopar% {
  set.seed(143996+i)
  ma92 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
  ma92[,1] <- 1
  Z=n(ma92,theta)
  label <- as.integer(runif(rows) < Z)
  ma921 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
  ma921[,1] <- 1
  Z1=n1(ma921,theta,sig)
  label1 <- as.integer(runif(rows) < Z1)
  model <- glm(label ~., 
               data = data.frame(ma92[,-1]), 
               family = binomial(link = "logit"))
  Mprob <- predict(model, data.frame(ma921[,-1]), type = "response")
  n_obs <- length(label1)
  
  
  greenwood <- ifelse(label1 == 1, runif(n_obs, 0, Mprob), runif(n_obs, Mprob, 1))
  ui <- c(0, sort(greenwood), 1)
  D <- diff(ui)
  D_sorted <- sort(D)
  n_D <- length(D_sorted)
  indices <- 0:(n_D - 1)
  
  
  term1 <- sum(D_sorted * indices)
  prefix_sum <- cumsum(c(0, D_sorted[-n_D]))  
  term2 <- sum(prefix_sum)
  Gn <- 2 * (term1 - term2)
  greenwood_stat <- (Gn - n_obs) / sqrt(n_obs / 3)
  greenwood_pval <- greenwood_stat^2
  
  
  hl_result <- tryCatch({
    hoslem.test(label1, Mprob, g = 10)
  }, error = function(e) NULL)
  
  
  nattino_result <- tryCatch({
    hltest(label1, Mprob, G = 10, outsample = TRUE)
  }, error = function(e) NULL)
  
  c(greenwood_pval = greenwood_pval,
    hl_pval = if(!is.null(hl_result)) hl_result$statistic else NA,
    nattino_pval = if(!is.null(nattino_result)) nattino_result$p.value else NA)
}


stopCluster(cl)

# alpha level
greenwood_pvals <- results[, 1]
hl_pvals <- results[, 2]
nattino_pvals <- results[, 3]



p1.05 <- mean(greenwood_pvals > qchisq(0.95, df = 1))
p2.05 <- mean(hl_pvals > qchisq(0.95, df = 10))
p3.05 <- mean(nattino_pvals < 0.05)


#  result
list(
  greenwood = c(p1.05 = p1.05),
  hl = c(p2.05 = p2.05),
  nattino = c(p3.05 = p3.05)
)

