library(ggplot2)
library(tidyr)
library(dplyr)
library(patchwork)

 
df_sigma <- data.frame(
  sigma = c(1, 1.5, 2, 2.5),
  hosmer = c(1, 1, 1, 1),
  greenwood = c(0.899, 0.999,1, 1),
  nattino = c(1, 1, 1, 1)
)

 
df_long_sigma <- df_sigma %>%
  pivot_longer(
    cols = -sigma,
    names_to = "method",
    values_to = "power"
  ) %>%
  mutate(
    method = case_when(
      method == "hosmer" ~ "Hosmer-Lemeshow",
      method == "greenwood" ~ "Greenwood",
      method == "nattino" ~ "Nattino",
      TRUE ~ method
    )
  )

 
create_plot_sigma <- function(data, title) {
  ggplot(data, aes(x = sigma, y = power, group = 1)) +
    geom_line(color = "steelblue", linewidth = 1) +
    geom_point(size = 3, color = "steelblue") +
    scale_x_continuous(
      breaks = c(1, 1.5, 2, 2.5),
      labels = c("1.0", "1.5", "2.0", "2.5")
    ) +
    scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
    labs(title = title, x = "σ value", y = "Rejection Rate") +
    theme_minimal() +
    theme(
      plot.title = element_text(face = "bold",hjust = 0.5, size = 15),
      legend.title = element_text(face = "bold",size = 16),
      legend.text = element_text(size = 16),
      axis.title = element_text(face = "bold",size = 16),
      axis.text = element_text(size = 12)
    )
}

 
plot_hosmer_sigma <- create_plot_sigma(
  df_long_sigma %>% filter(method == "Hosmer-Lemeshow"),
  "Hosmer-Lemeshow Test"
)

plot_greenwood_sigma <- create_plot_sigma(
  df_long_sigma %>% filter(method == "Greenwood"),
  "Greenwood Test"
)

plot_nattino_sigma <- create_plot_sigma(
  df_long_sigma %>% filter(method == "Nattino"),
  "Nattino Test"
)

 
combined_plot_sigma <- plot_hosmer_sigma + plot_greenwood_sigma + plot_nattino_sigma +
  plot_layout(ncol = 3)

 
combined_plot_sigma
ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 7.jpg"),
  plot = last_plot(),   
  device = "jpeg",      
  dpi = 800,
  width = 9,
  height = 6,
  units = "in"
)
