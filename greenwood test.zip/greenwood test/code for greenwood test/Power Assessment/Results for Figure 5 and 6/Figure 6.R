library(ggplot2)
library(tidyr)
library(dplyr)
library(patchwork)


df_new <- data.frame(
  n = c(5000, 10000,50000, 100000, 150000),
  hosmer = c(1, 1, 1, 1, 1),
  greenwood = c(0.266, 0.451, 0.977, 1, 1),
  nattino = c(1, 1, 1, 1, 1)
)

df_long_new <- df_new %>%
  pivot_longer(
    cols = -n,
    names_to = "method",
    values_to = "power"
  ) %>%
  mutate(
    method = case_when(
      method == "hosmer" ~ "Hosmer-Lemeshow",
      method == "greenwood" ~ "Greenwood",
      method == "nattino" ~ "Nattino",
      TRUE ~ method
    )
  )

x_breaks <- c(5000, 10000, 50000, 100000, 150000)
x_labels <- c("5e3", "1e4", "5e4", "1e5", "1.5e5")

create_plot <- function(data, title) {
  ggplot(data, aes(x = n, y = power)) +
    geom_line(color = "steelblue") +  
    geom_point(size = 3, color = "steelblue") +  
    scale_x_log10(
      breaks = x_breaks,
      labels = x_labels
    ) +
    scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
    labs(title = title, x = "Sample Size", y = "Rejection Rate") +
    theme_minimal() +
    theme(
      plot.title = element_text(face="bold",hjust = 0.5,size=15),
      legend.title = element_text( face = "bold", size = 16),
      legend.text = element_text(size = 16),
      axis.title = element_text(face = "bold",  size = 16),
      axis.text = element_text(size = 10)
    )
}

plot_hosmer_new <- create_plot(
  df_long_new %>% filter(method == "Hosmer-Lemeshow"),
  "Hosmer-Lemeshow Test"
)

plot_greenwood_new <- create_plot(
  df_long_new %>% filter(method == "Greenwood"),
  "Greenwood Test"
)

plot_nattino_new <- create_plot(
  df_long_new %>% filter(method == "Nattino"),
  "Nattino Test"
)

combined_plot_new <- plot_hosmer_new + plot_greenwood_new + plot_nattino_new +
  plot_layout(ncol = 3)

combined_plot_new
ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 6.jpg"),
  plot = last_plot(),   
  device = "jpeg",      
  dpi = 800,
  width = 9,
  height = 6,
  units = "in"
)

