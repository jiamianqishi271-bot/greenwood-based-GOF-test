library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)


######beta0=0.597

n <- function(x, theta) {
  prob <- 1 / (1 + exp(-((x) %*% theta)))
  return(prob)
}

n1 <- function(x, theta, sig) {
  f <- sig * exp(x[, 2] * x[, 3])
  prob <- 1 / (1 + exp(-((x) %*% theta + f)))
  return(prob)
}


col <- 2
cols <- col + 1
rows <- 1000
theta <- matrix(c(0.597, 0.483, 1.664))


set.seed(143997)
ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma9[, 1] <- 1


Z0 <- as.vector(n(ma9, theta))
Z1 <- as.vector(n1(ma9, theta, 1))
Z2 <- as.vector(n1(ma9, theta, 1.5))
Z3 <- as.vector(n1(ma9, theta, 2))
Z4 <- as.vector(n1(ma9, theta, 2.5))



df_density <- data.frame(
  True_Probability = Z0, 
  sigma_1 = Z1, 
  sigma_1.5 = Z2, 
  sigma_2 = Z3,
  sigma_2.5 = Z4
) %>%
  pivot_longer(
    cols = everything(), 
    names_to = "Probability_Type", 
    values_to = "Probability_Value"
  ) %>%
  mutate(Probability_Type = factor(Probability_Type,
                                   levels = c("True_Probability", "sigma_1", "sigma_1.5", "sigma_2", "sigma_2.5"),
                                   labels = c("True Probability", "σ = 1.0", "σ = 1.5", "σ = 2.0", "σ = 2.5")))


ggplot(df_density, aes(x = Probability_Value, fill = Probability_Type)) +
  geom_density(alpha = 0.6, color = NA) +   
  labs(
    x = "Probability Value",
    y = "Density",
    
  ) +
  scale_fill_manual(
    name=NULL,
    values = c(
    "True Probability" = "black",
    "σ = 1.0" = "#E41A1C", 
    "σ = 1.5" = "#377EB8", 
    "σ = 2.0" = "#4DAF4A",
    "σ = 2.5" = "#984EA3"
  )) +
  scale_x_continuous(labels = percent_format(), limits = c(0, 1)) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16, margin = margin(b = 10)),
    plot.subtitle = element_text(hjust = 0.5, size = 20, color = "gray40", margin = margin(b = 15)),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 16),
    legend.text = element_text(size = 16),
    axis.title = element_text(face = "bold", size = 16),
    axis.text = element_text(size = 16),
    panel.grid.major = element_line(color = "gray90", linewidth = 0.2),
    panel.grid.minor = element_blank()
  )
ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 2.jpg"),
  plot = last_plot(),  
  device = "jpeg",     
  dpi = 800,
  width = 8,
  height = 6,
  units = "in"
)



######beta0=-1
col <- 2
cols <- col + 1
rows <- 1000
theta <- matrix(c(-1, 0.483, 1.664))


set.seed(143997)
ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma9[, 1] <- 1


Z0 <- as.vector(n(ma9, theta))
Z1 <- as.vector(n1(ma9, theta, 1))
Z2 <- as.vector(n1(ma9, theta, 1.5))
Z3 <- as.vector(n1(ma9, theta, 2))
Z4 <- as.vector(n1(ma9, theta, 2.5))


df_density <- data.frame(
  True_Probability = Z0, 
  sigma_1 = Z1, 
  sigma_1.5 = Z2, 
  sigma_2 = Z3,
  sigma_2.5 = Z4
) %>%
  pivot_longer(
    cols = everything(), 
    names_to = "Probability_Type", 
    values_to = "Probability_Value"
  ) %>%
  mutate(Probability_Type = factor(Probability_Type,
                                   levels = c("True_Probability", "sigma_1", "sigma_1.5", "sigma_2", "sigma_2.5"),
                                   labels = c("True Probability", "σ = 1.0", "σ = 1.5", "σ = 2.0", "σ = 2.5")))


ggplot(df_density, aes(x = Probability_Value, fill = Probability_Type)) +
  geom_density(alpha = 0.6, color = NA) + 
  labs(
   
    x = "Probability Value",
    y = "Density",
    fill = "Probability Type"
  ) +
  
  scale_fill_manual(
    name=NULL
    ,values = c(
    "True Probability" = "black",
    "σ = 1.0" = "#E41A1C", 
    "σ = 1.5" = "#377EB8", 
    "σ = 2.0" = "#4DAF4A",
    "σ = 2.5" = "#984EA3"
  )) +
  scale_x_continuous(labels = percent_format(), limits = c(0, 1)) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16, margin = margin(b = 10)),
    plot.subtitle = element_text(hjust = 0.5, size = 20, color = "gray40", margin = margin(b = 15)),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 16),
    legend.text = element_text(size = 16),
    axis.title = element_text(face = "bold", size = 16),
    axis.text = element_text(size = 16),
    panel.grid.major = element_line(color = "gray90", linewidth = 0.2),
    panel.grid.minor = element_blank()
  )
ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 3.jpg"),
  plot = last_plot(),  
  device = "jpeg",     
  dpi = 800,
  width = 8,
  height = 6,
  units = "in"
)
