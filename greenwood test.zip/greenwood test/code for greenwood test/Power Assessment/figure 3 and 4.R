library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)

######beta0=-4

n <- function(x, theta) {
  prob <- 1 / (1 + exp(-((x) %*% theta)))
  return(prob)
}

n1 <- function(x, theta, sig) {
  f <- sig * exp(x[, 2] * x[, 3])
  prob <- 1 / (1 + exp(-((x) %*% theta + f)))
  return(prob)
}

col <- 2
cols <- col + 1
rows <- 1000
theta <- matrix(c(-4, 0.483, 1.664))

set.seed(143997)
ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma9[, 1] <- 1

Z0 <- as.vector(n(ma9, theta))
Z1 <- as.vector(n1(ma9, theta, 2))


df_density <- data.frame(
  True_Probability = Z0, 
  sigma_2 = Z1
) %>%
  pivot_longer(
    cols = everything(), 
    names_to = "Probability_Type", 
    values_to = "Probability_Value"
  ) %>%
  mutate(Probability_Type = factor(Probability_Type,
                                   levels = c("True_Probability", "sigma_2"),
                                   labels = c("True Probability", "σ = 2.0")))

ggplot(df_density, aes(x = Probability_Value, fill = Probability_Type)) +
  geom_density(alpha = 0.6, color = NA) +   
  labs(
    x = "Probability Value",
    y = "Density"
  ) +
  scale_fill_manual(
    name = NULL,
    values = c(
      "True Probability" = "black",
      "σ = 2.0" = "#4DAF4A"
    )
  ) +
  scale_x_continuous(labels = percent_format(), limits = c(0, 1)) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16, margin = margin(b = 10)),
    plot.subtitle = element_text(hjust = 0.5, size = 20, color = "gray40", margin = margin(b = 15)),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 16),
    legend.text = element_text(size = 16),
    axis.title = element_text(face = "bold", size = 16),
    axis.text = element_text(size = 16),
    panel.grid.major = element_line(color = "gray90", linewidth = 0.2),
    panel.grid.minor = element_blank()
  )

ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 3.jpg"),
  plot = last_plot(),  
  device = "jpeg",     
  dpi = 800,
  width = 8,
  height = 6,
  units = "in"
)

####β0=-4.5
library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)

######beta0=-4

n <- function(x, theta) {
  prob <- 1 / (1 + exp(-((x) %*% theta)))
  return(prob)
}

n1 <- function(x, theta, sig) {
  f <- sig * exp(x[, 2] * x[, 3])
  prob <- 1 / (1 + exp(-((x) %*% theta + f)))
  return(prob)
}

col <- 2
cols <- col + 1
rows <- 1000
theta <- matrix(c(-4.5, 0.483, 1.664))

set.seed(143997)
ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma9[, 1] <- 1

Z0 <- as.vector(n(ma9, theta))
Z1 <- as.vector(n1(ma9, theta, 2))


df_density <- data.frame(
  True_Probability = Z0, 
  sigma_2 = Z1
) %>%
  pivot_longer(
    cols = everything(), 
    names_to = "Probability_Type", 
    values_to = "Probability_Value"
  ) %>%
  mutate(Probability_Type = factor(Probability_Type,
                                   levels = c("True_Probability", "sigma_2"),
                                   labels = c("True Probability", "σ = 2.0")))

ggplot(df_density, aes(x = Probability_Value, fill = Probability_Type)) +
  geom_density(alpha = 0.6, color = NA) +   
  labs(
    x = "Probability Value",
    y = "Density"
  ) +
  scale_fill_manual(
    name = NULL,
    values = c(
      "True Probability" = "black",
      "σ = 2.0" = "#4DAF4A"
    )
  ) +
  scale_x_continuous(labels = percent_format(), limits = c(0, 1)) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16, margin = margin(b = 10)),
    plot.subtitle = element_text(hjust = 0.5, size = 20, color = "gray40", margin = margin(b = 15)),
    legend.position = "bottom",
    legend.title = element_text(face = "bold", size = 16),
    legend.text = element_text(size = 16),
    axis.title = element_text(face = "bold", size = 16),
    axis.text = element_text(size = 16),
    panel.grid.major = element_line(color = "gray90", linewidth = 0.2),
    panel.grid.minor = element_blank()
  )

ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 4.jpg"),
  plot = last_plot(),  
  device = "jpeg",     
  dpi = 800,
  width = 8,
  height = 6,
  units = "in"
)
