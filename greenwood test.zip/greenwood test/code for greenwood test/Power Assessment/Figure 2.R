n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
}

col <- 2
cols <- col + 1
theta <- matrix(c(-4,0.483,1.664))
theta1 <- matrix(c(-4.5,0.483,1.664))

sample_sizes <- c(5000, 10000, 50000,100000,150000)

results <- data.frame(sample_size = numeric(0), 
                      probability = numeric(0), 
                      model_type = character(0))

for (rows in sample_sizes) {
  set.seed(143396)
  ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
  ma9[, 1] <- 1
  
  Z2 <- n(ma9, theta)    
  Z1 <- n(ma9, theta1)   
  
  results <- rbind(results,
                   data.frame(sample_size = rows, 
                              probability = as.vector(Z2), 
                              model_type = "β0=-4"),
                   data.frame(sample_size = rows, 
                              probability = as.vector(Z1), 
                              model_type = "β0=-4.5"))
}

library(ggplot2)
library(dplyr)

library(ggplot2)
library(dplyr)


label_mapping <- data.frame(
  model_type = c("β0=-4", "β0=-4.5"),
  label = c("B", "A")   
)

label_data <- results %>%
  group_by(sample_size, model_type) %>%
  summarize(median_prob = median(probability),
            .groups = 'drop') %>%
  left_join(label_mapping, by = "model_type")

ggplot(results, aes(x = factor(sample_size), y = probability, fill = model_type)) +
  geom_boxplot(position = position_dodge(0.8), width = 0.6, 
               outlier.size = 0.8, alpha = 0.9, linewidth = 0.7) +
  
  
  geom_text(data = label_data, 
            aes(x = factor(sample_size), y = median_prob, 
                group = model_type, label = label),
            position = position_dodge(0.8), 
            vjust = -1.5, size = 5, fontface = "bold") +
  
  scale_fill_manual(values = c("β0=-4" = "#56B4E9",     
                               "β0=-4.5" = "#E69F00"),      
                    name = "Different intercept value",
                    labels = c("β0=-4" = "B: β0=-4",  
                               "β0=-4.5" = "A: β0=-4.5")) +
  
  scale_x_discrete(labels = c("5000", "10000","50000","100000", "150000")) +
  
  labs(x = "Sample Size", 
       y = "Probability") +
  
  theme_minimal() +
  theme(legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
        axis.title = element_text(size = 20),
        axis.text = element_text(size = 20),
        legend.text = element_text(size = 20),
        legend.title = element_text(size = 20, face = "bold"),
        panel.grid.major = element_line(color = "grey90"),
        panel.grid.minor = element_line(color = "grey95")) +
  
  coord_cartesian(ylim = c(0, 0.1)) +
  guides(fill = guide_legend(override.aes = list(alpha = 1)))


ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 2.jpg"),
  plot = last_plot(),   
  device = "jpeg",      
  dpi = 800,
  width = 9,
  height = 6,
  units = "in"
)
