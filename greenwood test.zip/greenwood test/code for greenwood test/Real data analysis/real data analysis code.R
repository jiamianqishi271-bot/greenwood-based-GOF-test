setwd(".")
options(stringsAsFactors = FALSE)

# Survival analysis and the stratified sample:
# https://towardsdatascience.com/survival-analysis-and-the-stratified-sample-2c2582aa9805

list.of.packages <- c("easypackages", "survival",  "dplyr", "survminer", "stats", "PRROC", "formula.tools", "dplyr", "pastecs")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

library("easypackages")
libraries(list.of.packages)

fileNameData<- "………\S1Data_EDITED2.csv" 
targetName <- "DEATH_EVENT"
patients_data <- read.csv(fileNameData, header = TRUE, sep =",")
cat("Read data from file ", fileNameData, "\n", sep="")



patients_data <- patients_data%>%select(-targetName,targetName)

target_index <- dim(patients_data)[2]

set.seed(1238)
# shuffle the rows
patients_data <- patients_data[sample(nrow(patients_data)),] 

num_to_return <- 1
upper_num_limit <- 10000000
exe_num <- sample(1:upper_num_limit, num_to_return)


cat("nrow(patients_data) = ", nrow(patients_data), "\n", sep="")
cat("ncol(patients_data) = ", ncol(patients_data), "\n", sep="")


# split training set and test set
training_set_perce <- 80
cat("training_set_perce = ", training_set_perce, "%\n", sep="")

# the training set is the first training_set_perce% of the whole dataset
training_set_first_index <- 1 # NEW
training_set_last_index <- round(dim(patients_data)[1]*training_set_perce/100) # NEW

# the test set is the last 20% of the whole dataset
test_set_first_index <- round(dim(patients_data)[1]*training_set_perce/100)+1 # NEW
test_set_last_index <- dim(patients_data)[1] # NEW

cat("[Creating the subsets for the values]\n")
prc_data_train <- patients_data[training_set_first_index:training_set_last_index, ] 
prc_data_test <- patients_data[test_set_first_index:test_set_last_index, ] 

prc_data_train_labels <- prc_data_train[, target_index] 
prc_data_test_labels <- prc_data_test[, target_index] 


#full model
glm_model <- glm(DEATH_EVENT ~ sex + smoking + diabetes + high_blood_pressure + anaemia + age + ejection_fraction + serum_sodium + serum_creatinine + platelets + creatinine_phosphokinase + factor(TIME_MONTH), data = prc_data_train, family = "binomial")



prc_data_test_pred1 <- predict(glm_model, prc_data_test, type = "response")
threshold <- 0.5
prc_data_test_pred_bin1 <- as.numeric(prc_data_test_pred1)

prc_data_test_pred_bin1[prc_data_test_pred_bin1>=threshold]<-1
prc_data_test_pred_bin1[prc_data_test_pred_bin1<threshold]<-0

rows <- nrow(prc_data_test)
greenwood_full <- numeric(rows)
for (j in 1:rows) {
  Mprob <- prc_data_test_pred1[j]
  greenwood_full[j] <- if (prc_data_test_labels[j] == 1) {
    runif(1, min = 0, max = Mprob)
  } else {
    runif(1, min = Mprob, max = 1)
  }
}
ui_full <- c(0, sort(greenwood_full), 1)
D_full <- diff(ui_full)
D_sorted_full <- sort(D_full)
m_full <- length(D_sorted_full)
prefix_sum_full <- c(0, cumsum(D_sorted_full))
term1_full <- sum(D_sorted_full * (0:(m_full-1)))
term2_full <- sum(prefix_sum_full[1:m_full])
Gn_full <- 2 * (term1_full - term2_full)
greenwood_stat_full <- (Gn_full - rows) / sqrt(rows/3)
greenwood_pval_full <- greenwood_stat_full^2
greenwood_pval_full
P_full<- pchisq(greenwood_pval_full, 1, lower.tail = FALSE)
P_full
#HL.test
library(ResourceSelection)
HL_result_full <- hoslem.test(prc_data_test_labels, prc_data_test_pred1, g = 10)
HLstat_full <- HL_result_full$statistic
HLstat_full 
P_full=pchisq(HLstat_full, 10, lower.tail = FALSE)
P_full


#ConfuseMatrix_full 
ConfuseMatrix_full=table(prc_data_test_labels,prc_data_test_pred_bin1)
ConfuseMatrix_full
prop.table(ConfuseMatrix_full,1)*100
tp=ConfuseMatrix_full[2,2]
tn=ConfuseMatrix_full[1,1]
fp=ConfuseMatrix_full[2,1]
fn=ConfuseMatrix_full[1,2]
print((tp+tn)/(tp+tn+fp+fn)) 

install.packages("pROC")
library(pROC)
roc=roc(prc_data_test_labels,as.numeric(prc_data_test_pred1))  
roc
 

#Optimize model
glm_model2 <- glm(DEATH_EVENT ~ ejection_fraction + serum_creatinine + factor(TIME_MONTH), data = prc_data_train, family = "binomial")
prc_data_test_pred2 <- predict(glm_model2, prc_data_test, type = "response")
threshold <- 0.5
prc_data_test_pred_bin2 <- as.numeric(prc_data_test_pred2)

prc_data_test_pred_bin2[prc_data_test_pred_bin2>=threshold]<-1
prc_data_test_pred_bin2[prc_data_test_pred_bin2<threshold]<-0

greenwood_simple <- numeric(rows)
for (j in 1:rows) {
  Mprob <- prc_data_test_pred2[j]
  greenwood_simple[j] <- if (prc_data_test_labels[j] == 1) {
    runif(1, min = 0, max = Mprob)
  } else {
    runif(1, min = Mprob, max = 1)
  }
}
ui_simple <- c(0, sort(greenwood_simple), 1)
D_simple <- diff(ui_simple)
D_sorted_simple <- sort(D_simple)
m_simple <- length(D_sorted_simple)
prefix_sum_simple <- c(0, cumsum(D_sorted_simple))
term1_simple <- sum(D_sorted_simple * (0:(m_simple-1)))
term2_simple <- sum(prefix_sum_simple[1:m_simple])
Gn_simple <- 2 * (term1_simple - term2_simple)
greenwood_stat_simple <- (Gn_simple - rows) / sqrt(rows/3)
greenwood_pval_op <- greenwood_stat_simple^2
greenwood_pval_op
P_op<- pchisq(greenwood_pval_op, 1, lower.tail = FALSE)
P_op

#HL.test
library(ResourceSelection)
HL_result_simple <- hoslem.test(prc_data_test_labels, prc_data_test_pred2, g = 10)
HLstat_op <- HL_result_simple$statistic
HLstat_op  
P_op=pchisq(HLstat_op, 10, lower.tail = FALSE)
P_op
 
#ConfuseMatrix_full 
ConfuseMatrix_op=table(prc_data_test_labels,prc_data_test_pred_bin2)
ConfuseMatrix_op
prop.table(ConfuseMatrix_op,1)*100
tp=ConfuseMatrix_op[2,2]
tn=ConfuseMatrix_op[1,1]
fp=ConfuseMatrix_op[2,1]
fn=ConfuseMatrix_op[1,2]
print((tp+tn)/(tp+tn+fp+fn)) 
tp/(tp+fp) 
tp/(tp+fn) 
library(pROC)
roc=roc(prc_data_test_labels,as.numeric(prc_data_test_pred2))  
roc

