col <- 2
cols <- col + 1
rows <-  50

n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
} 
theta <- matrix(c(0.597,0.483,1.664))
set.seed(1234)
ma92 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma92[,1] <- 1
Z=n(ma92,theta)
label <- as.integer(runif(rows) < Z)
model <- glm(label ~ ., 
             data = data.frame(ma92[, -1]), 
             family = binomial(link = "logit"))


Mprob <- predict(model, data.frame(ma92[, -1]), type = "response")
n_obs <- length(label)

n_simulations <- 1000
p_values1 <- numeric(n_simulations)   
for (i in 1:n_simulations) {

  greenwood <- ifelse(label == 1, runif(n_obs, 0, Mprob), runif(n_obs, Mprob, 1))
  ui <- c(0, sort(greenwood), 1)
  D <- diff(ui)
  D_sorted <- sort(D)
  n_D <- length(D_sorted)
  indices <- 0:(n_D - 1)
  
 
  term1 <- sum(D_sorted * indices)
  prefix_sum <- cumsum(c(0, D_sorted[-n_D]))   
  term2 <- sum(prefix_sum)
  Gn <- 2 * (term1 - term2)
  greenwood_stat <- (Gn - n_obs) / sqrt(n_obs / 3)
  greenwood_pval <- greenwood_stat^2
  
 
  p_values1[i] <- pchisq(greenwood_pval, df = 1, lower.tail = FALSE)
}
####################
col <- 2
cols <- col + 1
rows <-  50

n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
} 
theta <- matrix(c(-1,0.483,1.664))
set.seed(1234)
ma92 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma92[,1] <- 1
Z=n(ma92,theta)
label <- as.integer(runif(rows) < Z)
model <- glm(label ~ ., 
             data = data.frame(ma92[, -1]), 
             family = binomial(link = "logit"))
Mprob <- predict(model, data.frame(ma92[, -1]), type = "response")
n_obs <- length(label)
n_simulations <- 1000
p_values2 <- numeric(n_simulations)   
for (i in 1:n_simulations) {

  
  

  greenwood <- ifelse(label == 1, runif(n_obs, 0, Mprob), runif(n_obs, Mprob, 1))
  ui <- c(0, sort(greenwood), 1)
  D <- diff(ui)
  D_sorted <- sort(D)
  n_D <- length(D_sorted)
  indices <- 0:(n_D - 1)
  
  
  term1 <- sum(D_sorted * indices)
  prefix_sum <- cumsum(c(0, D_sorted[-n_D]))   
  term2 <- sum(prefix_sum)
  Gn <- 2 * (term1 - term2)
  greenwood_stat <- (Gn - n_obs) / sqrt(n_obs / 3)
  greenwood_pval <- greenwood_stat^2
  
  
  p_values2[i] <- pchisq(greenwood_pval, df = 1, lower.tail = FALSE)
}
#################
 
col <- 2
cols <- col + 1
rows <-  50

n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
} 
theta <- matrix(c(0.597,0.483,1.664))
set.seed(1234)
ma92 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma92[,1] <- 1
Z=n(ma92,theta)
label <- as.integer(runif(rows) < Z)
ma921 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma921[,1] <- 1
Z1=n(ma921,theta)
label1 <- as.integer(runif(rows) < Z1)
model <- glm(label ~., 
             data = data.frame(ma92[,-1]), 
             family = binomial(link = "logit"))
Mprob <- predict(model, data.frame(ma921[,-1]), type = "response")
n_obs <- length(label1)
n_simulations <- 1000
p_values3 <- numeric(n_simulations)   
for (i in 1:n_simulations) {
  

  greenwood <- ifelse(label1 == 1, runif(n_obs, 0, Mprob), runif(n_obs, Mprob, 1))
  ui <- c(0, sort(greenwood), 1)
  D <- diff(ui)
  D_sorted <- sort(D)
  n_D <- length(D_sorted)
  indices <- 0:(n_D - 1)
  
  
  term1 <- sum(D_sorted * indices)
  prefix_sum <- cumsum(c(0, D_sorted[-n_D]))   
  term2 <- sum(prefix_sum)
  Gn <- 2 * (term1 - term2)
  greenwood_stat <- (Gn - n_obs) / sqrt(n_obs / 3)
  greenwood_pval <- greenwood_stat^2
  
  
  p_values3[i] <- pchisq(greenwood_pval, df = 1, lower.tail = FALSE)
}

##################################
col <- 2
cols <- col + 1
rows <-  50

n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
} 
theta <- matrix(c(-1,0.483,1.664))
set.seed(1234)
ma92 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma92[,1] <- 1
Z=n(ma92,theta)
label <- as.integer(runif(rows) < Z)
ma921 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma921[,1] <- 1
Z1=n(ma921,theta)
label1 <- as.integer(runif(rows) < Z1)
model <- glm(label ~., 
             data = data.frame(ma92[,-1]), 
             family = binomial(link = "logit"))
Mprob <- predict(model, data.frame(ma921[,-1]), type = "response")
n_obs <- length(label1)
n_simulations <- 1000
p_values4 <- numeric(n_simulations)   
for (i in 1:n_simulations) {
  

  greenwood <- ifelse(label1 == 1, runif(n_obs, 0, Mprob), runif(n_obs, Mprob, 1))
  ui <- c(0, sort(greenwood), 1)
  D <- diff(ui)
  D_sorted <- sort(D)
  n_D <- length(D_sorted)
  indices <- 0:(n_D - 1)
  
  
  term1 <- sum(D_sorted * indices)
  prefix_sum <- cumsum(c(0, D_sorted[-n_D]))   
  term2 <- sum(prefix_sum)
  Gn <- 2 * (term1 - term2)
  greenwood_stat <- (Gn - n_obs) / sqrt(n_obs / 3)
  greenwood_pval <- greenwood_stat^2
  
  
  p_values4[i] <- pchisq(greenwood_pval, df = 1, lower.tail = FALSE)
}
#############
 
# 加载必要的包
library(ggplot2)
library(cowplot)
install.packages("gridGraphics")
library(gridGraphics)

 
create_qq_plot <- function(p_values, title) {
  # 创建基础图形
  qqplot(x = qunif(ppoints(length(p_values))),  
         y = p_values, 
         main = title,
         xlab = "Theoretical Uniform Quantiles",
         ylab = "Sample Quantiles",  cex.lab = 1.5,
         cex.main = 1.5) 
  abline(a = 0, b = 1, col = "red", lwd = 2)
}

 
par(mfrow = c(2, 2))

# 创建四个子图
create_qq_plot(p_values1, "Internal Validation (β0=0.597)")
create_qq_plot(p_values2, "Internal Validation (β0=-1)")
create_qq_plot(p_values3, "External Validation (β0=0.597)")
create_qq_plot(p_values4, "External Validation (β0=-1)")

 
jpeg(filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 2.jpg"), 
     width = 9, height = 6, units = "in", res = 1000)
par(mfrow = c(2, 2))
create_qq_plot(p_values1, "Internal Validation (β0=0.597)")
create_qq_plot(p_values2, "Internal Validation (β0=-1)")
create_qq_plot(p_values3, "External Validation (β0=0.597)")
create_qq_plot(p_values4, "External Validation (β0=-1)")
dev.off()

 
par(mfrow = c(1, 1))
