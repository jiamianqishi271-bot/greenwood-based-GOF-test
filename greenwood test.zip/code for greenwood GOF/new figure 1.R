n <- function(x, theta) {
  pro = 1 / (1 + exp(-((x) %*% theta)))
  return(pro)
}

col <- 2
cols <- col + 1
theta <- matrix(c(0.597,0.483,1.664))
theta1 <- matrix(c(-1,0.483,1.664))
theta2 <- matrix(c(-4,0.483,1.664))
theta4 <- matrix(c(-4.5,0.483,1.664))

sample_sizes <- c(50, 100, 1000, 10000, 100000, 150000)

results <- data.frame(sample_size = numeric(0), 
                      probability = numeric(0), 
                      model_type = character(0))

for (rows in sample_sizes) {
  set.seed(1234)
  ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
  ma9[, 1] <- 1
  
  Z2 <- n(ma9, theta)    
  Z1 <- n(ma9, theta1)   
  Z3 <- n(ma9, theta2)
  Z4 <- n(ma9, theta4)
  
  results <- rbind(results,
                   data.frame(sample_size = rows, 
                              probability = as.vector(Z2), 
                              model_type = "A: β0=0.597"),
                   data.frame(sample_size = rows, 
                              probability = as.vector(Z1), 
                              model_type = "B: β0=-1"),
                   data.frame(sample_size = rows, 
                              probability = as.vector(Z3), 
                              model_type = "C: β0=-4"),
                   data.frame(sample_size = rows, 
                              probability = as.vector(Z4), 
                              model_type = "D: β0=-4.5"))
}

library(ggplot2)
library(dplyr)

 
results$model_type <- factor(results$model_type, 
                             levels = c("A: β0=0.597", "B: β0=-1", "C: β0=-4", "D: β0=-4.5"))

 
  color_palette <- c(
    "A: β0=0.597" = "#4E79A7",    
    "B: β0=-1" = "#F28E2B",       
    "C: β0=-4" = "#59A14F",       
    "D: β0=-4.5" = "#E15759"      
  )

 
ggplot(results, aes(x = factor(sample_size), y = probability, fill = model_type)) +
  geom_boxplot(position = position_dodge(0.8), 
               width = 0.7, 
               outlier.size = 0.6, 
               outlier.alpha = 0.6,
               alpha = 0.85, 
               linewidth = 0.5,
               coef = 1.5) +
  
 
  scale_fill_manual(values = color_palette,
                    name = "Different intercept value ") +
  
 
  scale_x_discrete(labels = c("50", "100", "1,000", "10,000", "100,000", "150,000")) +
  
 
  labs(x = "Sample Size", 
       y = "Probability") +
  
 
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "bottom",
    plot.title = element_blank(),
    plot.subtitle = element_blank(),
    axis.title = element_text(size = 18),
    axis.text = element_text(size = 18),
    axis.text.x = element_text(angle = 0, hjust = 0.5),
    legend.text = element_text(size = 12),
    legend.title = element_text(size = 13),
    panel.grid.major = element_line(color = "grey88", linewidth = 0.3),
    panel.grid.minor = element_line(color = "grey92", linewidth = 0.2),
    panel.background = element_rect(fill = "white", color = NA),
    plot.background = element_rect(fill = "white", color = NA),
    legend.box.spacing = unit(0.2, "cm"),
    legend.margin = margin(t = 10, b = 5),
    plot.margin = margin(20, 20, 20, 20)
  ) +
  
 
  scale_y_continuous(limits = c(0, 1), 
                     breaks = seq(0, 1, 0.2),
                     expand = expansion(mult = c(0.02, 0.05))) +
  
 
  guides(fill = guide_legend(nrow = 2, 
                             byrow = TRUE,
                             override.aes = list(alpha = 1, size = 0.5)))
ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 1.jpg"),
  plot = last_plot(),   
  device = "jpeg",      
  dpi = 1000,
  width = 9,
  height = 6,
  units = "in"
)
