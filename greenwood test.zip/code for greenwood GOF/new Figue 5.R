library(ggplot2)
library(tidyr)
library(dplyr)
library(patchwork)

df_new <- data.frame(
  n = c(5000, 10000,50000, 100000, 150000),
  hosmer = c(0.1035, 0.1255, 0.2770, 0.4745, 0.6375),
  hosmer1 = c(1, 1, 1, 1, 1),
  greenwood = c(0.0540, 0.0510, 0.0550, 0.0535, 0.0470),
  greenwood1 = c(0.1805, 0.2915, 0.8870, 0.9955, 1),
  nattino = c(0.1055, 0.1220, 0.2510, 0.4185, 0.5405),
  nattino1 = c(1, 1, 1, 1, 1)
)

df_long_new <- df_new %>%
  pivot_longer(
    cols = -n,
    names_to = "method",
    values_to = "power"
  ) %>%
  mutate(
    sigma = ifelse(grepl("1$", method), "σ=2", "σ=0.01"),
    method = case_when(
      grepl("hosmer", method) ~ "Hosmer-Lemeshow",
      grepl("greenwood", method) ~ "Greenwood", 
      grepl("nattino", method) ~ "Nattino",
      TRUE ~ method
    )
  )

x_breaks <- c(5000, 10000, 50000, 100000, 150000)
x_labels <- c("5e3", "1e4", "5e4", "1e5", "1.5e5")

create_plot <- function(data, title) {
  ggplot(data, aes(x = n, y = power, color = sigma, linetype = sigma)) +
    geom_line() +  
    geom_point(size = 3) +  
    scale_x_log10(
      breaks = x_breaks,
      labels = x_labels
    ) +
    scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
    scale_color_manual(values = c("σ=0.01" = "orange", "σ=2" = "blue")) +
    scale_linetype_manual(values = c("σ=0.01" = "solid", "σ=2" = "dashed")) +
    labs(title = title, x = "Sample Size", y = "Rejection Rate", color = "Sigma", linetype = "Sigma") +
    theme_minimal() +
    theme(
      plot.title = element_text(  hjust = 0.5, size = 15),
      legend.title = element_text(  size = 15),
      legend.text = element_text(size = 15),
      axis.title = element_text(  size = 14),
      axis.text = element_text(size = 8,face = "bold")
    )
}

plot_hosmer_new <- create_plot(
  df_long_new %>% filter(method == "Hosmer-Lemeshow"),
  "Hosmer-Lemeshow Test"
)

plot_greenwood_new <- create_plot(
  df_long_new %>% filter(method == "Greenwood"),
  "Greenwood Test"
)

plot_nattino_new <- create_plot(
  df_long_new %>% filter(method == "Nattino"),
  "Nattino Test"
)

combined_plot_new <- plot_hosmer_new + plot_greenwood_new + plot_nattino_new +
  plot_layout(ncol = 3, guides = "collect") &
  theme(legend.position = "bottom")

combined_plot_new
ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 5.jpg"),
  plot = last_plot(),   
  device = "jpeg",      
  dpi = 1000,
  width = 9,
  height = 6,
  units = "in"
)

