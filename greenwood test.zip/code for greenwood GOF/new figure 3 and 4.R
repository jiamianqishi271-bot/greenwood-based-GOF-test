library(ggplot2)
library(dplyr)
library(tidyr)
library(scales)

######beta0=-4

n <- function(x, theta) {
  prob <- 1 / (1 + exp(-((x) %*% theta)))
  return(prob)
}

n1 <- function(x, theta, sig) {
  f <- sig * exp(x[, 2] * x[, 3])
  prob <- 1 / (1 + exp(-((x) %*% theta + f)))
  return(prob)
}

col <- 2
cols <- col + 1
rows <- 10000
theta <- matrix(c(-4, 0.483, 1.664))

set.seed(1234)
ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma9[, 1] <- 1

Z0 <- as.vector(n(ma9, theta))
Z1 <- as.vector(n1(ma9, theta, 0.01))
Z2 <- as.vector(n1(ma9, theta, 2))


df_scatter <- data.frame(
  True_Probability = Z0,
  sigma_0.02 = Z1,
  sigma_2 = Z2
) %>%
  pivot_longer(
    cols = c(sigma_0.02, sigma_2),
    names_to = "Model_Type", 
    values_to = "Prediction_Value"
  ) %>%
  mutate(Model_Type = factor(Model_Type,
                             levels = c("sigma_0.02", "sigma_2"),
                             labels = c("σ = 0.02", "σ = 2.0")))

ggplot(df_scatter, aes(x = True_Probability, y = Prediction_Value, color = Model_Type)) +
  geom_point(alpha = 0.6, size = 1) +   
  geom_abline(intercept = 0, slope = 1, color = "black", linetype = "dashed", linewidth = 1) +
  labs(
    x = "Probabilities from Model without non-Linear Components  (Model (3))",
    y = "Probabilities from Model with non-Linear Components (Model (4))"
  ) +
  scale_color_manual(
    name = NULL,
    values = c(
      "σ = 0.02" = "#E41A1C",
      "σ = 2.0" = "#4DAF4A"
    ),
    guide = guide_legend(
      override.aes = list(size = 4, alpha = 1)   
    )
  ) +
  scale_x_continuous(limits = c(0, 1)) +
  scale_y_continuous(limits = c(0, 1)) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5,  size = 16, margin = margin(b = 10)),
    plot.subtitle = element_text(hjust = 0.5, size = 20, color = "gray40", margin = margin(b = 15)),
    legend.position = "bottom",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 14),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 12),
    panel.grid.major = element_line(color = "gray90", linewidth = 0.2),
    panel.grid.minor = element_blank()
  )

ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 3.jpg"),
  plot = last_plot(),  
  device = "jpeg",     
  dpi = 1000,
  width = 8,
  height = 6,
  units = "in"
)

####β0=-4.5
n <- function(x, theta) {
  prob <- 1 / (1 + exp(-((x) %*% theta)))
  return(prob)
}

n1 <- function(x, theta, sig) {
  f <- sig * exp(x[, 2] * x[, 3])
  prob <- 1 / (1 + exp(-((x) %*% theta + f)))
  return(prob)
}

col <- 2
cols <- col + 1
rows <- 10000
theta <- matrix(c(-4.5, 0.483, 1.664))

set.seed(1234)
ma9 <- matrix(rnorm(rows * cols, mean = 0, sd = 1), nrow = rows, ncol = cols)
ma9[, 1] <- 1

Z0 <- as.vector(n(ma9, theta))
Z1 <- as.vector(n1(ma9, theta, 0.01))
Z2 <- as.vector(n1(ma9, theta, 2))


df_scatter <- data.frame(
  True_Probability = Z0,
  sigma_0.02 = Z1,
  sigma_2 = Z2
) %>%
  pivot_longer(
    cols = c(sigma_0.02, sigma_2),
    names_to = "Model_Type", 
    values_to = "Prediction_Value"
  ) %>%
  mutate(Model_Type = factor(Model_Type,
                             levels = c("sigma_0.02", "sigma_2"),
                             labels = c("σ = 0.02", "σ = 2.0")))

ggplot(df_scatter, aes(x = True_Probability, y = Prediction_Value, color = Model_Type)) +
  geom_point(alpha = 0.6, size = 1) +   
  geom_abline(intercept = 0, slope = 1, color = "black", linetype = "dashed", linewidth = 1) +
  labs(
    x = "Probabilities from Model without non-Linear Components  (Model (3))",
    y = "Probabilities from Model with non-Linear Components (Model (4))"
  ) +
  scale_color_manual(
    name = NULL,
    values = c(
      "σ = 0.02" = "#E41A1C",
      "σ = 2.0" = "#4DAF4A"
    ),
    guide = guide_legend(
      override.aes = list(size = 4, alpha = 1)   
    )
  ) +
  scale_x_continuous(limits = c(0, 1)) +
  scale_y_continuous(limits = c(0, 1)) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5,  size = 16, margin = margin(b = 10)),
    plot.subtitle = element_text(hjust = 0.5, size = 20, color = "gray40", margin = margin(b = 15)),
    legend.position = "bottom",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 14),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 12),
    panel.grid.major = element_line(color = "gray90", linewidth = 0.2),
    panel.grid.minor = element_blank()
  )
ggsave(
  filename = file.path(Sys.getenv("USERPROFILE"), "Desktop", "Figure 4.jpg"),
  plot = last_plot(),  
  device = "jpeg",     
  dpi = 1000,
  width = 8,
  height = 6,
  units = "in"
)
